insert into paciente (prontuario, nome, cpf, convenio, data_consulta, especialidade)
VALUES (11, 'Maria', 11111111, 'UNIMED', '2021-08-26', 'Neurologia');
insert into paciente (prontuario, nome, cpf, convenio, data_consulta, especialidade)
VALUES (25, 'Lucas', 22222222, 'UNIMED', '2021-08-26', 'Neurologia');