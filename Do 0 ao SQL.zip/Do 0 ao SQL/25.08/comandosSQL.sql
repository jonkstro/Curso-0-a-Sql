create table hospital(
  cnpj int NOT NULL PRIMARY KEY,
  nome TEXT NOT NULL,
  endereco TEXT NOT NULL,
  cod_paciente int NOT NULL
);