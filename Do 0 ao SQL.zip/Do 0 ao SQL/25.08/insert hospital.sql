INSERT INTO hospital (cnpj, nome, endereco, cod_paciente)
VALUES (5555555, 'SANTA CASA', 'RUA SAO JOSE', 25);