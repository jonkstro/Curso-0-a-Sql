SELECT * from paciente, hospital WHERE paciente.prontuario=hospital.cod_paciente;
SELECT * FROM paciente;